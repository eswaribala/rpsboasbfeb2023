package com.boa.resillience4j;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Resillience4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
