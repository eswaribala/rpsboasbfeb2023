package com.boa.resillience4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Resillience4jApplication {

	public static void main(String[] args) {
		SpringApplication.run(Resillience4jApplication.class, args);
	}

}
